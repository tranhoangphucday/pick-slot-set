-- Meme Set Matcher: shared cloud state
-- Run this in Supabase Dashboard > SQL Editor.
create table if not exists public.shared_state (
  id integer primary key check (id = 1),
  state jsonb not null default '{"people":[],"sets":[],"history":[],"nextId":1,"lastRun":null}'::jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

alter table public.shared_state enable row level security;

-- Every authenticated team account can access the shared workspace.
-- Create accounts only for trusted organizers in Authentication > Users.
drop policy if exists "authenticated users can read shared state" on public.shared_state;
create policy "authenticated users can read shared state"
  on public.shared_state for select to authenticated
  using (auth.uid() is not null);

drop policy if exists "authenticated users can insert shared state" on public.shared_state;
create policy "authenticated users can insert shared state"
  on public.shared_state for insert to authenticated
  with check (auth.uid() is not null);

drop policy if exists "authenticated users can update shared state" on public.shared_state;
create policy "authenticated users can update shared state"
  on public.shared_state for update to authenticated
  using (auth.uid() is not null)
  with check (auth.uid() is not null);

-- Enable Realtime updates for other devices. If this reports that the table
-- is already in the publication, it is already enabled and you can ignore it.
do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'shared_state'
  ) then
    alter publication supabase_realtime add table public.shared_state;
  end if;
end $$;
