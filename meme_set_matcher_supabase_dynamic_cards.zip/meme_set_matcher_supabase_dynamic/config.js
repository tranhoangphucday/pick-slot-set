// Điền thông tin từ Supabase > Project Settings > API.
// Chỉ dùng Project URL và publishable/anon key ở trình duyệt.
// TUYỆT ĐỐI KHÔNG đặt service_role/secret key tại đây.
window.MEME_SUPABASE_URL = "YOUR_PROJECT_URL";
window.MEME_SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY";
