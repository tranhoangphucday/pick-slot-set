# Meme Set Matcher — Supabase cloud version

This is a static, mobile-responsive website starter with Supabase email/password login and shared cloud data.

## Before you begin
- Create a Supabase project.
- This app uses a single shared JSONB row (`shared_state`, id=1) to sync the current workspace. It is a simple starter; for simultaneous heavy editing, a normalized schema and server-side conflict handling are better.
- Only create accounts for trusted organizers. Every authenticated account can see and edit the same shared workspace.
- Never put a Supabase `service_role` or secret key in browser code.

## Step-by-step setup

### 1. Create Supabase project
1. Visit https://supabase.com and sign in.
2. Choose New project; choose a project name and database password, then wait for provisioning.
3. Open Project Settings > API (or Connect, depending on dashboard layout).
4. Copy the Project URL and the publishable/anon public key.

### 2. Create cloud table and access policies
1. In Supabase, open SQL Editor > New query.
2. Open `supabase_setup.sql` from this folder and copy all its SQL.
3. Paste into SQL Editor and click Run.
4. If the final `alter publication` line says the table is already included, that is okay; remove that one line and run the rest if needed.

### 3. Configure the website
1. Open `config.js`.
2. Replace `YOUR_PROJECT_URL` with your Project URL.
3. Replace `YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY` with the public anon/publishable key.
4. Save the file. Do not use a `service_role` or secret key.

### 4. Create login accounts for organizers
1. In Supabase, open Authentication > Users.
2. Click Add user / Create new user.
3. Enter the organizer's email and a temporary password. Create one account per trusted organizer.
4. Share credentials securely and ask each organizer to change/reset their password.
5. For this starter, keep public sign-ups disabled if the dashboard setting is available. There is no public sign-up form in this website.

### 5. Publish on the web
Recommended easiest option:
1. Create a GitHub repository at https://github.com.
2. Upload `index.html`, `config.js`, `manifest.webmanifest` (if included), and this folder's files. `index.html` and `config.js` must be at the published root.
3. Import that repository into https://vercel.com or https://www.netlify.com and deploy as a static site. No build command is needed; output/root directory should be the folder containing `index.html`.
4. Open the HTTPS URL, sign in, add a test participant, and check the Cloud status says “Đã đồng bộ”.
5. Open the same URL on another phone/computer and sign in with a second organizer account. Confirm the participant appears there too.
6. On iPhone Safari use Share > Add to Home Screen. On Android Chrome use menu > Add to Home screen / Install app.

### 6. Test before real use
- Add one participant and save.
- Open the site on a second device and sign in.
- Edit or add a test participant and check sync.
- Export CSV as a backup before entering the real full list.

## Matching rules
Card types are configurable on the website: open Card > Thêm loại card to add a new required slot (for example, increase from 6 to 10), rename or delete types there. Every non-Random type is one required slot in each full set. Random fills one missing required slot; each Random copy is used at most once. The cardTypes configuration is stored in the shared Supabase JSON state and syncs to signed-in devices.

## Important limitations
- The shared row approach is appropriate for a small trusted organizing team and simple use.
- If two devices edit at exactly the same moment, last write can overwrite the earlier write. For large teams, upgrade to normalized participant/card tables with transactional allocation.
- The website stores Facebook URLs and participant data. Give access only to trusted organizers.
- Local data is not automatically merged with cloud data. Import CSV or manually transfer local data before switching to this cloud version.
